import win32com.client
import os
import time


class Application(object):
    def __init__(self) -> None:
        self.application = win32com.client.Dispatch("PowerPoint.Application")
        self.application.Visible = 1


class Presentation:
    def __init__(self) -> None:
        self.app = None
        self.presentation = None

    def create():
        pass

    def open(self, file_name):
        pass

    def close(self):
        self.presentation.Close()
        self.app.Quit()

    def save():
        pass

    def save_as():
        pass


class Presentations(Application):
    def add(self) -> Presentation:
        presentation_ref = Presentation()
        presentation_ref.app = self.application
        presentation_ref.presentation = self.application.Presentations.Add()
        return presentation_ref

    def open(self, file_name: str) -> Presentation:
        self.application.Presentations.Open()
        presentation_ref = Presentation()
        presentation_ref.app = self.application
        presentation_ref.presentation = self.application.Presentations.Open(file_name)
        return presentation_ref


class Side:
    pass


if __name__ == "__main__":
    ppt = Presentations()
    
