# pyautoppt

## 基本用法

```python
from pyautoppt import ppt

# 新建 ppt文件
pre_ref = ppt.add()
# 添加幻灯片
pre_ref.slides.add(1,12)

```
